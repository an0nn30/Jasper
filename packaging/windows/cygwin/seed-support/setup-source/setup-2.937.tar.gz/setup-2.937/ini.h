/*
 * Copyright (c) 2000,2007 Red Hat, Inc.
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     A copy of the GNU General Public License can be found at
 *     http://www.gnu.org/
 *
 * Written by DJ Delorie <dj@cygnus.com>
 *
 */

#ifndef SETUP_INI_H
#define SETUP_INI_H

#include "win32.h"
#include <string>
#include <vector>

typedef std::vector <std::string> IniList;
extern IniList found_ini_list, setup_ext_list;

extern bool is_new_install;
std::string SetupArch();
std::string SetupBaseName();

class io_stream;
class IniDBBuilder;
class Feedback;

void ini_init (io_stream *, IniDBBuilder *, Feedback &);
bool do_ini_thread (Feedback &feedback);

#define YYSTYPE char *

/* When setup.ini is parsed, the information is stored according to
   the declarations here.  ini.cc (via inilex and iniparse)
   initializes these structures.  choose.cc sets the action and trust
   fields.  download.cc downloads any needed files for selected
   packages (the chosen "install" field).  install.cc installs
   selected packages. */

extern int yyparse ();

/* The following definitions are used in the parser implementation */

#define hexnibble(val)  ('\xff' & (val > '9') ? val - 'a' + 10 : val - '0')
#define nibbled1(v1,v2) ('\xff' & ((v1 << 4) | v2))
#define b64url(val)						\
  ('\x3f' & ((  val == '_') ? '\x3f'				\
	     : (val == '-') ? '\x3e'				\
	     : (val >= 'a') ? val - 'a' + '\x1a'		\
	     : (val >= 'A') ? val - 'A' + '\x00'		\
	     :                val - '0' + '\x34'))
#define b64d1(v1,v2,v3,v4) ('\xff' & ((v1 << 2) | (v2 >> 4)))
#define b64d2(v1,v2,v3,v4) ('\xff' & ((v2 << 4) | (v3 >> 2)))
#define b64d3(v1,v2,v3,v4) ('\xff' & ((v3 << 6) |  v4))

#endif /* SETUP_INI_H */

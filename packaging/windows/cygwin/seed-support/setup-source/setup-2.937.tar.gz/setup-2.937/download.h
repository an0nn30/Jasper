/*
 * Copyright (c) 2001, Robert Collins.
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     A copy of the GNU General Public License can be found at
 *     http://www.gnu.org/
 *
 * Written by Robert Collins <rbtcollins@hotmail.com>
 *
 */

#ifndef SETUP_DOWNLOAD_H
#define SETUP_DOWNLOAD_H

#include "Feedback.h"

class packagesource;
int check_for_cached (packagesource & pkgsource, Feedback &feedback,
                      bool mirror_mode = false, bool check_hash = true);

#endif /* SETUP_DOWNLOAD_H */
